-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 04, 2017 at 08:11 PM
-- Server version: 5.6.34
-- PHP Version: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes`
--
DROP DATABASE IF EXISTS `shoes`;
CREATE DATABASE IF NOT EXISTS `shoes` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`name`, `id`) VALUES
('brnd 1', 56),
('brand 2', 57);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`name`, `id`) VALUES
('store 10000', 57),
('store 2', 58);

-- --------------------------------------------------------

--
-- Table structure for table `stores_brands`
--

CREATE TABLE `stores_brands` (
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores_brands`
--

INSERT INTO `stores_brands` (`store_id`, `brand_id`, `id`) VALUES
(57, 56, 24),
(57, 57, 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores_brands`
--
ALTER TABLE `stores_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `stores_brands`
--
ALTER TABLE `stores_brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;--
-- Database: `shoes_test`
--
DROP DATABASE IF EXISTS `shoes_test`;
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `name` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stores_brands`
--

CREATE TABLE `stores_brands` (
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores_brands`
--

INSERT INTO `stores_brands` (`store_id`, `brand_id`, `id`) VALUES
(2, 5, 1),
(768, 167, 2),
(780, 175, 3),
(792, 183, 4),
(804, 191, 5),
(816, 199, 6),
(828, 207, 7),
(840, 215, 8),
(852, 223, 9),
(864, 231, 10),
(876, 239, 11),
(877, 240, 12),
(877, 241, 13),
(889, 249, 14),
(890, 250, 15),
(890, 251, 16),
(902, 259, 17),
(903, 260, 18),
(903, 261, 19),
(915, 269, 20),
(916, 270, 21),
(916, 271, 22),
(928, 279, 23),
(929, 280, 24),
(929, 281, 25),
(942, 290, 26),
(943, 291, 27),
(943, 292, 28),
(944, 300, 29),
(956, 301, 30),
(957, 302, 31),
(957, 303, 32),
(958, 311, 33),
(970, 312, 34),
(971, 313, 35),
(971, 314, 36),
(972, 322, 37),
(984, 323, 38),
(985, 324, 39),
(985, 325, 40),
(986, 333, 41),
(998, 334, 42),
(999, 335, 43),
(999, 336, 44),
(1000, 344, 45),
(1001, 345, 46),
(1002, 345, 47),
(1014, 346, 48),
(1015, 347, 49),
(1015, 348, 50),
(1016, 356, 51),
(1017, 357, 52),
(1018, 357, 53),
(1030, 358, 54),
(1031, 359, 55),
(1031, 360, 56),
(1032, 368, 57),
(1033, 369, 58),
(1034, 369, 59),
(1046, 370, 60),
(1047, 371, 61),
(1047, 372, 62),
(1048, 380, 63),
(1049, 381, 64),
(1050, 381, 65),
(1062, 382, 66),
(1063, 383, 67),
(1063, 384, 68),
(1064, 392, 69),
(1065, 393, 70),
(1066, 393, 71),
(1078, 395, 73),
(1079, 396, 74),
(1079, 397, 75),
(1080, 405, 76),
(1081, 406, 77),
(1082, 406, 78),
(1094, 408, 80),
(1095, 409, 81),
(1095, 410, 82),
(1096, 418, 83),
(1097, 419, 84),
(1098, 419, 85),
(1110, 421, 87),
(1111, 422, 88),
(1111, 423, 89),
(1112, 431, 90),
(1113, 432, 91),
(1114, 432, 92),
(1126, 434, 94),
(1127, 435, 95),
(1127, 436, 96),
(1128, 444, 97),
(1129, 445, 98),
(1130, 445, 99),
(1144, 457, 100),
(1145, 458, 101),
(1146, 458, 102),
(1160, 470, 103),
(1161, 471, 104),
(1162, 471, 105),
(1174, 473, 107),
(1175, 474, 108),
(1175, 475, 109),
(1176, 483, 110),
(1177, 484, 111),
(1178, 484, 112),
(1190, 486, 114),
(1191, 487, 115),
(1191, 488, 116),
(1192, 496, 117),
(1193, 497, 118),
(1194, 497, 119);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores_brands`
--
ALTER TABLE `stores_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stores_brands`
--
ALTER TABLE `stores_brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=120;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
